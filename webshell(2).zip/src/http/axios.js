
import http from 'axios'
import store from '@/store'
import router from '@/router'
import { h, getCurrentInstance } from 'vue'


export default http
let baseURL = 'http://192.168.100.22:8082'
// 全局配置
Object.assign(http.defaults, {
  baseURL: baseURL, // url = base url + request url
  timeout: 60000,
  headers: 'application/json'
})//192.168.100.173 192.168.50.240 172.80.125.18:26689
console.log(baseURL);

http.interceptors.request.use(
  function (config) {
    // 配置 CancelToken
    // 使用相对路径
    config.headers['Content-Type'] = 'application/json'

    return config
  },
  function (error) {
    return Promise.reject(error)
  }
)

// 拦截响应
// http.interceptors.response.use(
//   function (response) {
//     const d = response.data;
//     // 全局处理请求成功，增加 success 字段
//     if (d && (d.resCode === 10000 || d.resCode === 20201)) {
//       d.success = true;
//     } else if (d.resCode === 20108) {
//       window.vm.$message.error("旧密码错误");
//     }
//     if (d.resCode > 200 && d.resCode < 300) {

//     }
//     // 用户登录已过期
//     else if (d.code === 'A0230' || d.code === 'A0220') {
//       const reason = '用户登录已过期，请重新登录'
//       // 取消其他请求
//       source.cancel(reason)
//       // 重新生成 CancelToken
//       source = http.CancelToken.source()

//       // 注销登录
//       if (!globalLogout) {
//         globalLogout = true
//         store.dispatch('logout')
//         setTimeout(() => {
//           globalLogout = false
//         }, 1000)
//       }
//     } else if (d.code === 'A02301') {
//       // 取消其他请求
//       source.cancel('当前账号已在其他电脑上登录')
//       // 重新生成 CancelToken
//       source = http.CancelToken.source()
//       isLoginKickout = true
//       if (!globalLogout) {
//         globalLogout = true
//         // 先把token清掉 防止其他接口请求再次弹窗
//         store.commit('UPDATE_USER', { access_token: '' })

//         setTimeout(() => {
//           globalLogout = false
//         }, 1000)
//       }
//     }


//     return response;
//   },
//   function (error) {
//     const { response } = error
//     if (http.isCancel(error)) {
//       if (isLoginKickout) {
//         // success true是为了不弹出报错提示
//         return Promise.resolve({ data: { code: 0, success: true } })
//       }
//       return Promise.resolve({ data: { code: 0 } })
//     }
//     let msg = error.message
//     if (response.data) {
//       switch (response.data.resCode) {
//         case 20103:
//           window.vm.$message.error("账号不存在");
//           break;
//         case 20101:
//           window.vm.$message.error('密码错误')
//           break;
//         default:
//           break;
//       }
//     }
//     if (response.data) {
//       switch (response.data.resCode) {
//         case 20101:
//           window.vm.$message.error('密码错误')
//           break;
//         default:
//           break;
//       }
//     }
//     //捕获到401返回登录页消除token
//     if (response.status === 401) {
//       router.push('/dialogLogin')
//     }

//     console.log("msgmsg", msg);
//     // 请求发出，得到非200状态码
//     if (error.response) {
//       const status = error.response.status
//       msg = ErrorMap[status] || `请求错误（${status}）`
//     }
//     // 请求发出，没有响应
//     else if (error.request) {
//       if (msg.indexOf('timeout of') !== -1) {
//         msg = '请求超时，请重试'
//       }
//       if (msg === 'Network Error') {
//         msg = navigator.onLine ? '网络状况不好，请重试' : '当前网络不稳定，请检查网络'
//       }
//     }
//     // 其他错误导致请求未发出
//     else {
//       msg = `请求错误：${error.message}`
//     }
//     console.error(msg)

//     // 把错误信息扶正, 后面就不需要写 catch
//     return Promise.resolve({ data: { msg } })
//   }
// )
