import { createStore } from 'vuex'
import http from '@/http/axios'
export default createStore({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
    getassetsBrand(store, params) {
      return http.post('/to_reson/', params).then(res => {
        return res.data
      })
    },
    getDrvicetabledata() {
      return http.get('/drvice_true/').then(res => {
        return res.data
      })
    },
    getSrcipttabledata() {
      return http.get('/srcipt_true/').then(res => {
        return res.data
      })
    },
    getCreateInput(store, params) {
      return http.post('/create_input/', params).then(res => {
        return res.data
      })
    },
    getClean() {
      return http.delete('/clean_all/').then((res) => {
        return res.data
      })
    },
    getActiondata(store, params) {
      return http.post('/to_data/', params).then((res) => {
        return res.data
      })
    },
    getNewDrivcetabledata(store, params) {
      return http.post('/s_ture/', params).then((res) => {
        return res.data
      })
    },
  },
  modules: {
  }
})
