<template>
  <div
    style="
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    "
  >
    <div class="container">
      <div style="flex: 35%">
        <el-input
          v-model="filterText"
          placeholder="Please input"
          class="input-with-select"
          style="margin-top: 10px"
        >
          <template #append>
            <el-button :icon="Search" @click="searchButton" />
          </template>
        </el-input>
        <div style="display: flex; flex-direction: column; height: 100%">
          <div class="TreeOne">
            <el-tree
              :data="data"
              :props="props"
              show-checkbox
              ref="tree"
              node-key="id"
              @check="handleNodeClick"
              :filter-node-method="filterNode"
            />
          </div>
          <el-input
            v-model="filterText1"
            placeholder="Please input"
            class="input-with-select"
            style="margin-top: 15px"
          >
            <template #append>
              <el-button :icon="Search" @click="searchButton" />
            </template>
          </el-input>
          <div class="TreeTwo">
            <el-tree
              :data="data1"
              :props="props1"
              show-checkbox
              ref="tree1"
              node-key="id"
              @check="handleNodeClickSrcipt"
              :filter-node-method="filterNode1"
              check-strictly
            />
          </div>
        </div>
      </div>
      <div style="flex: 65%; margin-left: 30px">
        <div class="input-group">
          <div style="display: flex; flex-wrap: wrap">
            <el-input
              style="flex: 45%; margin: 10px 10px"
              v-for="(item, index) in modules"
              :key="index"
              v-model="item.ip"
              maxlength="20"
              show-word-limit
              type="text"
            />
          </div>
        </div>
        <div class="input-area">
          <div style="display: flex; justify-content: space-between">
            <el-button class="CMDS_button" @click="ClickCMDS" type="primary"
              >预览脚本</el-button
            >
            <el-button class="CMDS_button" @click="CleanButton" type="primary"
              >清理缓存</el-button
            >
          </div>
          <div class="scrollbar-demo-item such">
            <el-input
              style="height: 200px"
              v-model="CMDSarea"
              placeholder="脚本示例"
              clearable
              :autosize="{ minRows: 10, maxRows: 20 }"
              type="textarea"
              :disabled="true"
            />
          </div>
        </div>
        <div>
          <div
            style="
              display: flex;
              justify-content: space-between;
              margin-top: 30px;
              align-items: center;
            "
            class="input-area"
          >
            <div>
              <el-button
                class="Action_btn"
                @click="ActionButton"
                type="primary"
                :loading="loading"
                >执行</el-button
              >
            </div>
            <div>
              <el-pagination
                background
                layout="prev, pager, next"
                :total="total"
                @current-change="pageChange"
                :current-page="CurrentPage"
              />
            </div>
          </div>
          <div class="scrollbar-demo-item return">
            <el-input
              style="height: 400px"
              v-model="returnMessage"
              placeholder="返回内容"
              :autosize="{ minRows: 15, maxRows: 17 }"
              clearable
              :disabled="true"
              type="textarea"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Search } from "@element-plus/icons-vue";
export default {
  name: "HomeView",
  components: {},
  data() {
    this.Search = Search;
    return {
      select: "",
      filterText: "",
      filterText1: "",
      CMDSarea: "",
      returnMessage: "",
      props: {
        label: "name",
        children: "children",
        disabled: "disabled",
      },
      props1: {
        label: "name",
        children: "children",
        disabled: "disabled",
      },
      ip: "",
      data: [{}],
      data1: [{}],
      count: 0,
      script: "",
      device: [],
      inputList: [],
      modules: [],
      createInputData: [{}],
      loading: false,
      timer: null,
      timer1: null,
      i: 0,
      arr: "",
      list: [],
      all: {},
      total: 20,
      index: [],
      implementKey: [],
      ReturnMessage: {},
      CurrentPage: 1,
    };
  },
  watch: {
    // 过滤操作
    filterText(val) {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.$refs.tree.filter(val);
      }, 1000);
    },
    filterText1(val) {
      clearTimeout(this.timer1);
      this.timer1 = setTimeout(() => {
        this.$refs.tree1.filter(val);
      }, 1000);
    },
  },
  methods: {
    handleNodeClick(data, node) {
      //deviceid树，点击子则加入子id，点击父加入所有子
      if (data.children) {
        this.arr = data.name;
      } else {
        this.arr = this.$refs.tree.getNode(data).parent.data.name;
      }
      let params = {
        device_type: this.arr,
      };
      this.$store.dispatch("getNewDrivcetabledata", params).then((res) => {
        this.data1 = res.data[0].children;
      });
      if (data.children === undefined) {
        let Name = this.$refs.tree.getNode(data).parent.data.name;
        this.device = this.all[Name];
        Object.keys(this.all).forEach((key) => {
          if (key !== Name) {
            this.all[key] = [];
          } else {
            const index = this.all[key].findIndex((i) => i.id === data.id);
            if (~index) {
              this.all[key].splice(index, 1);
            } else {
              this.all[key].push(data);
            }
          }
        });
        this.$refs.tree.setCheckedNodes(this.all[Name]);
      } else {
        this.device = data.children;
        this.$refs.tree.setCheckedNodes([data]);
      }
    },
    async handleNodeClickSrcipt(data, node) {
      //动态创建input，获取数据发送请求
      this.script = data.id;
      let params = { srciptid: this.script };
      this.modules = [];
      await this.$store.dispatch("getCreateInput", params).then((res) => {
        this.createInputData = res.data;
        this.inputList = res.data1;
        for (const iterator of this.inputList) {
          this.modules.push({ ip: iterator });
        }
      });
      //点击单选框发送请求，获取内容框内容
      let paramsReson = {
        srciptid: this.script,
      };
      let inputList1 = this.inputList;
      let modules1 = this.modules;
      inputList1.filter((item, index) => {
        paramsReson[item] = modules1[index].ip;
      });
      await this.$store
        .dispatch("getassetsBrand", { ...paramsReson })
        .then((res) => {
          this.CMDSarea = res.ret_data2;
        });
      this.$refs.tree1.setCheckedNodes([]);
      this.$refs.tree1.setCheckedNodes([data]);
    },
    ClickCMDS() {
      //点击后可修改内容
      let params = {
        srciptid: this.script,
      };
      let inputList = this.inputList;
      let modules = this.modules;
      inputList.filter((item, index) => {
        params[item] = modules[index].ip;
      });

      this.$store.dispatch("getassetsBrand", { ...params }).then((res) => {
        this.CMDSarea = res.ret_data2;
      });
    },
    gettabledata() {
      this.$store.dispatch("getDrvicetabledata").then((res) => {
        this.data = res.data[0].children;
        this.data.filter((item) => {
          let itemName = item.name;
          this.all[itemName] = [];
        });
      });
      this.$store.dispatch("getSrcipttabledata").then((res) => {
        this.data1 = res.data[0].children;
      });
    },
    CleanButton() {
      this.CMDSarea = "";
      this.modules = [];
      this.$store.dispatch("getClean").then((res) => {
        console.log(res);
      });
    },
    ActionButton() {
      this.loading = true;
      this.device.forEach((item) => {
        this.index.push(item.id);
      });
      let params = {
        deviceid: this.index,
      };
      this.ReturnMessage = {};
      this.implementKey = [];
      this.returnMessage = [];
      this.CurrentPage = 1;
      this.$store.dispatch("getActiondata", params).then((res) => {
        Object.keys(res.ret_data1).forEach((item) => {
          this.implementKey.push(item);
          this.ReturnMessage = res.ret_data1;
          let Reskey = this.implementKey[0];
          this.returnMessage = this.ReturnMessage[Reskey];
        });
        this.total = this.implementKey.length * 10;

        if (res.ret_data1) {
          this.loading = false;
          this.index = [];
        } else {
          window.vm.$message.error("该请求无返回内容");
          this.loading = false;
        }
      });
    },
    searchButton() {
      this.filterNode(this.input);
    },
    filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },
    filterNode1(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },
    pageChange(value) {
      let index = this.implementKey[value - 1];
      this.returnMessage = this.ReturnMessage[index];
      this.CurrentPage = value;
    },
  },
  created() {
    this.gettabledata();
  },
};
</script>
<style scoped>
.container {
  display: flex;
  min-width: 90%;
  margin: auto;
  padding: 20px;
  background-color: #fff;
  height: 90%;
  overflow: hidden;
}
.input-group {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 80px;
}
.input-area {
  width: 100%;
  margin: auto;
}
.CMDS_button {
  margin: 10px 0;
}
.Action_btn {
  margin: 10px 0;
}
.TreeOne {
  margin-top: 15px;
  height: 30%;
  overflow-y: scroll;
}
.TreeTwo {
  margin-top: 15px;
  height: 55%;
  overflow-y: scroll;
}
::-webkit-scrollbar {
  display: none;
}
</style>